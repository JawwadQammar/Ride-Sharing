package com.ridesharing.drivermanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriverManagementApplicationTests {

    @Test
    void contextLoads () {
    }

}
