package com.ridesharing.passengermanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassengerManagementApplicationTests {

    @Test
    void contextLoads () {
    }

}
