package com.ridesharing.billingmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingManagementApplicationTests {

    @Test
    void contextLoads () {
    }

}
